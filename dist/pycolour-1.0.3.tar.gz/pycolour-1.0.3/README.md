# pycolour

Easily colour your text in the command line

- Black
- Red
- Green
- Yellow
- Blue
- Purple
- Cyan
- White
- Bold
- Normal
- end

Usage:
```print(pycolour.red + "Red Text" + pycolour.end)```

Use: ```import pycolour as p``` instead of: ```import pycolour``` to make referencing easier